$ErrorActionPreference='Continue'
Set-Location F:/photocraft
$env:PATH="$env:USERPROFILE/.cargo/bin;$env:PATH"
$env:CARGO_BUILD_JOBS='2'
$reviewRoot='F:/photocraft/plan/panel-repair/pr-ready-2026-10-31'
function Invoke-ReviewCargo([string]$label, [string[]]$arguments) {
 & cargo @arguments *> "$reviewRoot/$label.log"
 Set-Content "$reviewRoot/$label.exit" $LASTEXITCODE
 Get-Content "$reviewRoot/$label.log" -Tail 3
}
Invoke-ReviewCargo 'full-ui' @('test','--locked','-p','photocraft-ui-egui','--lib','--','--test-threads=2')
$matches=Select-String -Path "$reviewRoot/full-ui.log" -Pattern 'Running unittests.*\((.*photocraft_ui_egui[^)]*\.exe)\)' | Select-Object -Last 1
if (-not $matches) { throw 'No newly built UI test binary; stop dependent checks.' }
$testBinary=Join-Path 'F:/photocraft' $matches.Matches[0].Groups[1].Value
Set-Content "$reviewRoot/test-binary.txt" $testBinary
Invoke-ReviewCargo 'workspace-integration' @('test','--locked','-p','photocraft-ui-egui','--test','it','workspace','--','--test-threads=2')
function Invoke-ReviewBinary([string]$label,[string[]]$arguments) {
 & $testBinary @arguments *> "$reviewRoot/$label.log"
 Set-Content "$reviewRoot/$label.exit" $LASTEXITCODE
 Get-Content "$reviewRoot/$label.log" -Tail 3
}
Invoke-ReviewBinary 'all-panels' @('panel_docking','--test-threads=2')
$env:PHOTOCRAFT_NATIVE_HEIGHT_CAPTURES="$reviewRoot/matrix"
Invoke-ReviewBinary 'native-matrix' @('capture_native_height_and_document_header_review','--test-threads=1')
Remove-Item Env:PHOTOCRAFT_NATIVE_HEIGHT_CAPTURES
$env:PHOTOCRAFT_DESKTOP_REVIEW_CAPTURES="$reviewRoot/matrix"
Invoke-ReviewBinary 'desktop-matrix' @('capture_desktop_review_matrix','--test-threads=1')
Remove-Item Env:PHOTOCRAFT_DESKTOP_REVIEW_CAPTURES
$env:PHOTOCRAFT_FOURTH_REVIEW_CAPTURES="$reviewRoot/matrix"
Invoke-ReviewBinary 'seam-matrix' @('capture_fourth_review_seams','--test-threads=1')
Remove-Item Env:PHOTOCRAFT_FOURTH_REVIEW_CAPTURES
$env:PHOTOCRAFT_FINAL_REVIEW_CAPTURES="$reviewRoot/matrix"
Invoke-ReviewBinary 'final-transitions' @('capture_final_review_transitions','--test-threads=1')
Remove-Item Env:PHOTOCRAFT_FINAL_REVIEW_CAPTURES
Invoke-ReviewBinary 'active-panel-benchmark' @('benchmark_panel_hover_and_drag_frames','--ignored','--nocapture','--test-threads=1')
Invoke-ReviewCargo 'desktop-check' @('check','--locked','-p','photocraft','--all-targets')
Invoke-ReviewCargo 'clippy' @('clippy','--locked','-p','photocraft-ui-egui','--all-targets','--','-D','warnings')
Invoke-ReviewCargo 'clippy-no-deps' @('clippy','--locked','-p','photocraft-ui-egui','--all-targets','--no-deps','--','-D','warnings')
Invoke-ReviewCargo 'wasm' @('xtask','wasm')
Invoke-ReviewCargo 'layers' @('xtask','layers')
Invoke-ReviewCargo 'fmt' @('fmt','--all','--','--check')
