from github_client import api,OUT
import json
pr=api('/repos/storytold/photocraft/pulls/10322');sha=pr['head']['sha']
checks=api('/repos/storytold/photocraft/commits/'+sha+'/check-runs')
status=api('/repos/storytold/photocraft/commits/'+sha+'/status')
for name,data in [('pr-after',pr),('check-runs-after',checks),('status-after',status)]:
 (OUT/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
summary={'url':pr['html_url'],'draft':pr['draft'],'head':sha,'base':pr['base']['sha'],'mergeable':pr['mergeable'],'mergeable_state':pr['mergeable_state'],'checks':[{'id':x['id'],'name':x['name'],'status':x['status'],'conclusion':x['conclusion'],'url':x['details_url']} for x in checks['check_runs']],'statuses':[{'context':x['context'],'state':x['state'],'url':x['target_url']} for x in status['statuses']]}
(OUT/'PR_STATUS.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
