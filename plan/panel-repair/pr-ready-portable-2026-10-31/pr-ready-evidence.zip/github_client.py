from pathlib import Path
import json,os,subprocess,urllib.request,urllib.error
ROOT=Path('F:/photocraft')
OUT=ROOT/'plan/panel-repair/pr-ready-2026-10-31'
def api(path,method='GET',data=None):
    env=os.environ | {'GIT_TERMINAL_PROMPT':'0','GCM_INTERACTIVE':'never'}
    result=subprocess.run(['git','-c','credential.interactive=false','credential','fill'],input='protocol=https\nhost=github.com\n\n',capture_output=True,text=True,env=env,cwd=ROOT)
    credential=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
    token=credential.get('password')
    if result.returncode or not token: raise RuntimeError('GitHub credential unavailable')
    headers={'User-Agent':'Photocraft-dev','Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json'}
    req=urllib.request.Request('https://api.github.com'+path,data=None if data is None else json.dumps(data).encode(),headers=headers,method=method)
    try:
        with urllib.request.urlopen(req,timeout=60) as response: return json.load(response)
    except urllib.error.HTTPError as error:
        raise RuntimeError('GitHub API HTTP '+str(error.code)+' at '+path) from None
if __name__=='__main__':
    pr=api('/repos/storytold/photocraft/pulls/10322')
    assert pr['head']['repo']['full_name']=='KotovGGG/photocraft' and pr['head']['ref']=='codex/panel-layout-upstream'
    assert pr['state']=='open' and not pr['merged']
    (OUT/'pr-before.json').write_text(json.dumps(pr,indent=2)+'\n',encoding='utf-8')
    for name,path in [('reviews','/repos/storytold/photocraft/pulls/10322/reviews?per_page=100'),('review-comments','/repos/storytold/photocraft/pulls/10322/comments?per_page=100'),('check-runs','/repos/storytold/photocraft/commits/'+pr['head']['sha']+'/check-runs'),('status','/repos/storytold/photocraft/commits/'+pr['head']['sha']+'/status')]:
        data=api(path);(OUT/(name+'-before.json')).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:pr[k] for k in ['number','state','draft','mergeable','mergeable_state','commits','changed_files']},indent=2))
    print(json.dumps({'head':pr['head']['sha'],'base':pr['base']['sha'],'node_id':pr['node_id']}))
    comments=json.loads((OUT/'review-comments-before.json').read_text())
    print(json.dumps([{'id':c['id'],'path':c['path'],'line':c['line'],'original_line':c['original_line'],'body':c['body'][:1800]} for c in comments],indent=2))
