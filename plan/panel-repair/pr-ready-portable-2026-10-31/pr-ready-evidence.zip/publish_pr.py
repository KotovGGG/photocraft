from github_client import api,ROOT,OUT
import json,subprocess
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='d0e052e48434fa13f4ad60eebd20eb125bacac24'
pr=api('/repos/storytold/photocraft/pulls/10322')
assert pr['state']=='open' and not pr['merged']
assert pr['head']['sha']==head and pr['head']['repo']['full_name']=='KotovGGG/photocraft' and pr['head']['ref']=='codex/panel-layout-upstream'
assert pr['base']['ref']=='main' and pr['base']['repo']['full_name']=='storytold/photocraft'
body=(OUT/'PR.md').read_text(encoding='utf-8')
updated=api('/repos/storytold/photocraft/pulls/10322','PATCH',{'body':body})
assert updated['body']==body and updated['head']['sha']==head
(OUT/'pr-body-updated.json').write_text(json.dumps({k:updated[k] for k in ['number','html_url','state','draft','updated_at']},indent=2)+'\n',encoding='utf-8')
query='''query { repository(owner:"storytold", name:"photocraft") { pullRequest(number:10322) { id reviewThreads(first:100) { nodes { id isResolved comments(first:10) { nodes { databaseId path } } } } } } }'''
data=api('/graphql','POST',{'query':query})
if data.get('errors'):raise RuntimeError(json.dumps(data['errors']))
node=data['data']['repository']['pullRequest'];assert node['id']==pr['node_id']
expected={4424209701:'ATTRIBUTION.md',4424209716:'docs/panel-docking-validation.md'}
resolved=[]
for thread in node['reviewThreads']['nodes']:
 comments=thread['comments']['nodes']
 if any(c['databaseId'] in expected and c['path']==expected[c['databaseId']] for c in comments):
  if not thread['isResolved']:
   result=api('/graphql','POST',{'query':'mutation($id:ID!) { resolveReviewThread(input:{threadId:$id}) { thread { id isResolved } } }','variables':{'id':thread['id']}})
   if result.get('errors'):raise RuntimeError(json.dumps(result['errors']))
   assert result['data']['resolveReviewThread']['thread']['isResolved']
  resolved.append(thread['id'])
(OUT/'resolved-review-threads.json').write_text(json.dumps(resolved,indent=2)+'\n',encoding='utf-8')
if updated['draft']:
 result=api('/graphql','POST',{'query':'mutation($id:ID!) { markPullRequestReadyForReview(input:{pullRequestId:$id}) { pullRequest { number url isDraft state headRefOid baseRefOid mergeable mergeStateStatus reviewDecision } } }','variables':{'id':pr['node_id']}})
 if result.get('errors'):raise RuntimeError(json.dumps(result['errors']))
 ready=result['data']['markPullRequestReadyForReview']['pullRequest'];assert ready['isDraft'] is False and ready['headRefOid']==head
else:
 ready={'number':updated['number'],'url':updated['html_url'],'isDraft':updated['draft'],'headRefOid':updated['head']['sha']}
(OUT/'pr-ready.json').write_text(json.dumps(ready,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'ready':ready,'resolved_threads':resolved},indent=2))
