from github_client import api,OUT
import json
path=OUT/'manual-review-request.json'
if path.exists():
 print(path.read_text())
else:
 pr=api('/repos/storytold/photocraft/pulls/10322')
 assert not pr['draft'] and pr['state']=='open' and pr['head']['sha']=='d0e052e48434fa13f4ad60eebd20eb125bacac24'
 comment=api('/repos/storytold/photocraft/issues/10322/comments','POST',{'body':'@coderabbitai review'})
 summary={k:comment[k] for k in ['id','html_url','created_at','body']}
 path.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
