from github_client import api,OUT
import json
query='''query { repository(owner:"storytold", name:"photocraft") { pullRequest(number:10322) { id isDraft headRefOid baseRefOid mergeStateStatus reviewDecision reviewThreads(first:100) { nodes { id isResolved isOutdated comments(first:10) { nodes { databaseId path } } } } } } }'''
data=api('/graphql','POST',{'query':query})
(OUT/'graphql-before.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2))
