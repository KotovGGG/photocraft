from pathlib import Path
import json,subprocess,hashlib,shutil,zipfile
root=Path('F:/photocraft');r=root/'plan/panel-repair/pr-ready-2026-10-31';portable=root/'plan/panel-repair/pr-ready-portable-2026-10-31';portable.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='d0e052e48434fa13f4ad60eebd20eb125bacac24'
paths=subprocess.check_output(['git','diff','--name-only','upstream/main',head],cwd=root,text=True).splitlines()
assert not any(p.startswith(('.github/','contributors/','crates/psd/','crates/io/')) for p in paths)
source={'code_commit':'88da5a9142c9c55bbb9fb93abe8ddc5192f83929','pr_head':head,'upstream_main':'422ca7beda90d927643bcd074646ebbd37706d75','shared_revision':'c5a1cbfb5f9049f9270955caffb5bee5997aebf7','git_blobs':{p:subprocess.check_output(['git','rev-parse',head+':'+p],cwd=root,text=True).strip() for p in paths},'worktree_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'hash_kind':'SHA-256 of Windows worktree bytes; git_blobs are checkout-independent object IDs'}
(r/'source.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
visuals=sorted((r/'matrix').glob('*.png'));assert len(visuals)==444
(r/'visual-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in visuals},indent=2)+'\n',encoding='utf-8')
demos=r/'demos';demos.mkdir(exist_ok=True)
for name in ['below-document-tabs.gif','compact-group-height.gif','floating-bottom-resize.gif','full-height-after.png','top-collapse-after.png','LICENSE-MIT','LICENSE-APACHE','README.md']:
 shutil.copyfile(root/'docs/images/panel-repair'/name,demos/name)
report='''# Отправка PR #10322 — 2026-10-31

Пользователь проверил свой исправленный v0.18.0 EXE и сообщил, что больше не видит крупных проблем. Подпись в About оставлена автоматической: @KotovGGG, без изменения contributors.

Проверенный код: 88da5a9142c9c55bbb9fb93abe8ddc5192f83929. Итоговый PR head d0e052e48434fa13f4ad60eebd20eb125bacac24 отличается от него документацией и изображениями. Включён актуальный main 422ca7beda90d927643bcd074646ebbd37706d75. После ручной приёмки main обновил updater dialog и craft-libs; эта последняя интеграция проверена автоматически, без повторной нативной приёмки пользователем.

Изменения main сохранены. Единственный конфликт Cargo.lock разрешён с сохранением явного vendor override. Ревизия craft-libs c5a1cbfb5f9049f9270955caffb5bee5997aebf7 согласована с зависимостями и контрактом. Четыре обновлённых файла скопированы без изменений; аудит подтвердил 76 исходных файлов, идентичных pinned upstream, и ровно шесть файлов локального docking-патча. Проверка cargo metadata --locked прошла.

164 панельных + 9 workspace integration тестов прошли. Полный shared UI suite: 579 passed, включая 346 docking. Desktop all-targets cargo check, fmt, layers (31 crate), wasm (24 + codecs/heif) прошли. Полный UI library suite: 4494 passed, 95 failed, 23 ignored. Имена всех 95 сбоев точно совпали с предыдущим исправленным v0.18.0 snapshot; новых нет. Это не зелёный suite и не независимо повторённый baseline чистого main.

Clippy остаётся незелёным: стандартный UI check останавливается на неизменённом text/src/psd_path.rs:157; UI --no-deps сообщает прежние пять расположений в strokes/vp_ui/text_field/color_picker tests. Standalone shared Clippy сообщает два nonminimal_bool на docking/render/preview.rs:120, идентичном pinned upstream. Suppressions, изменения CI и посторонние исправления не добавлены.

444 новых PNG, все четыре capture-теста и проверки швов прошли. 443 PNG побайтно совпали с предыдущей проверенной версией; оставшийся drag-preview просмотрен рядом с прежним, изменений геометрии не обнаружено. Обновлены две after PNG и три GIF. CPU kittest по 600 samples: p50 idle/hover/drag 2.273/2.268/2.473 ms, drag p95 2.982 ms. Это не native FPS/GPU latency. Новые engine/corpus/broad perf результаты не заявляются. Основной EXE агентом не собирался и не запускался.

Существующий PR https://github.com/storytold/photocraft/pull/10322 обновлён и переведён из Draft в Ready for review. GitHub подтвердил mergeable=true; main ещё НЕ получил эти изменения. Оба прежних замечания CodeRabbit решены. Новый обзор бота запрошен одним комментарием @coderabbitai review. Точные временные внешние статусы находятся в PR_STATUS.json; они могут измениться. Merge PR, второй PR и включение auto-merge не выполнялись.

Живые focus/IME, физические мониторы/mixed-DPI и GPU/input latency отдельно не сертифицированы. Подробная английская приёмка хранится в docs/panel-docking-validation.md итогового PR. Архив содержит raw logs, JSON-манифесты, кадры, GIF и точный текст описания PR.
'''
(r/'RESULTS_RU.md').write_text(report,encoding='utf-8')
readme='''# PR #10322 готов к ревью

PR: https://github.com/storytold/photocraft/pull/10322
Код: d0e052e48434fa13f4ad60eebd20eb125bacac24, ветка origin/codex/panel-layout-upstream.
Последний проверенный code commit: 88da5a9142c9c55bbb9fb93abe8ddc5192f83929 (после него только docs/assets).

Сначала прочитать RESULTS_RU.md, PR_STATUS.json и docs/panel-docking-validation.md. Полный UI suite и строгий Clippy НЕ зелёные, ограничения явно раскрыты. Пользователь сообщил об успешной проверке своего исправленного EXE до последнего main/shared-widget merge. Новое объединение покрыто автоматическими проверками; отдельная native/IME/mixed-DPI/GPU сертификация не заявляется.

Восстановление:

```powershell
git clone --branch codex/panel-layout-upstream https://github.com/KotovGGG/photocraft.git
Set-Location photocraft
git restore --source origin/codex/panel-layout-handoff-2026-10-31 --worktree -- plan/panel-repair/pr-ready-portable-2026-10-31
Expand-Archive -LiteralPath plan/panel-repair/pr-ready-portable-2026-10-31/pr-ready-evidence.zip -DestinationPath plan/panel-repair/pr-ready-2026-10-31
```

Если checkout уже существует, сначала проверить git status, ветку и remotes. Не сбрасывать изменения или профиль. Не распаковывать поверх своих материалов без проверки. Основной EXE собирает пользователь; тестовые/offscreen сборки разрешены. Новые коммиты только KotovGGG, подпись About только @KotovGGG. Не трогать посторонние ATN/PSD, action names/text, CI и чужие credits. Не создавать второй PR и не выполнять merge PR без новой прямой инструкции.

Следующий шаг — дождаться ревью/проверок существующего PR, проверить замечания по текущему коду и исправлять только подтверждённые проблемы. Не скрывать исходные незелёные гейты и не менять CI ради feature/fix PR. Не повторять команду CodeRabbit, пока текущий обзор выполняется.

Предыдущий пакет f8c0c4a72 остаётся в portable-2026-10-31 на этой же handoff-ветке. Исходный аудит находится в handoff-ветке 2026-10-30. Старые матрицы и результаты не считать приёмкой будущего main.
'''
(portable/'README_RU.md').write_text(readme,encoding='utf-8')
for name in ['RESULTS_RU.md','PR.md','PR_STATUS.json','source.json','verification-results.json','full-ui-classification.json','vendor-source-audit.json','visual-comparison.json','visual-sha256.json']:
 shutil.copyfile(r/name,portable/name)
archive=portable/'pr-ready-evidence.zip'
files=sorted(p for p in r.rglob('*') if p.is_file() and 'craft-libs-audit.git' not in p.parts and '__pycache__' not in p.parts)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,str(p.relative_to(r)).replace('\\','/'))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
assert archive.stat().st_size<90*1024*1024
(portable/'SHA256SUMS.json').write_text(json.dumps({'pr-ready-evidence.zip':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'archive_mib':round(archive.stat().st_size/1024/1024,2),'files':len(files),'head':head}))
