Hosts drawing compact columns or custom group chrome need to use the workspace's fitted rectangles without also receiving stock painting/input. This adds opt-in host hooks and independent floating resize axes while retaining one shared layout model.

Changes:
- Report fitted column rectangles, allow exclusive iconic columns/custom groups, and forward all hooks through `show_customized`.
- Allow host-owned seam painting and horizontal floating sizing while preserving stock vertical handles, including at corners.
- Add an optional side-dock gap and top-gutter opt-out. Default hooks remain no-op/false; constructors preserve the normal gap and both resize axes. Exhaustive `DockStyle` literals need `dock_gap: None`.
- Keep dock seam input above sibling canvas input and avoid pointer-derived focus on empty headers.

Scope: six implementation files, one focused test module and its registration, and README. No application code, vendored snapshot, fonts, binary assets, dependency/CI changes or additional layout tree.

Five new tests cover corner-axis behavior (including stock defaults), top gutter geometry, exclusive-group forwarding/targets, fitted iconic-column callbacks, and invalid numeric gaps.

Validation:
__VALIDATION__

This is the first, focused extraction from storytold/photocraft#10322 following the maintainer's request to split that large PR. Accepting these APIs lets PhotoCraft pin an immutable upstream revision and remove its roughly 41k-line shared-library snapshot. The remaining PhotoCraft integration/persistence, compact/resize and Tools changes will follow as dependent PRs with their own tests.
