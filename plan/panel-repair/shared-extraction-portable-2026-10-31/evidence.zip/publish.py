from pathlib import Path
import sys,json
sys.path.insert(0,'F:/photocraft/plan/panel-repair/pr-ready-2026-10-31')
from github_client import api
r=Path('F:/photocraft/plan/panel-repair/shared-extraction-2026-10-31')
existing=api('/repos/storytold/craft-libs/pulls?state=open&head=KotovGGG:codex/docking-host-geometry')
if existing:pr=existing[0]
else:pr=api('/repos/storytold/craft-libs/pulls','POST',{'title':'Add opt-in docking host surfaces and fitted resize chrome','head':'KotovGGG:codex/docking-host-geometry','base':'main','body':(r/'PR.md').read_text(encoding='utf-8'),'draft':False})
assert pr['head']['sha']=='dcd94c27e79e4795441339527df5bef64654b4f2'
summary={'number':pr['number'],'url':pr['html_url'],'head':pr['head']['sha'],'draft':pr['draft'],'changed_files':pr['changed_files'],'additions':pr['additions'],'deletions':pr['deletions']}
(r/'shared-pr.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
body='The first focused extraction is ready: '+pr['html_url']+' — 9 files, +341/-23 lines, with five new shared regression tests. The complete craft-ui package passes (584 unit, 10 integration and 8 doctests); fmt and wasm pass. The unchanged workspace/Clippy blockers are disclosed in that PR. Please review the shared API there first. Once accepted, I will pin its upstream commit in PhotoCraft, remove the 41k-line vendored snapshot, and prepare the remaining dependent PhotoCraft PRs. #10322 remains the complete tested reference in the meantime.'
c=api('/repos/storytold/photocraft/issues/10322/comments','POST',{'body':body})
summary['photocraft_update']=c['html_url'];(r/'shared-pr.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
