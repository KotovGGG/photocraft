from pathlib import Path
import zipfile,hashlib,json,shutil,subprocess
root=Path('F:/photocraft');r=root/'plan/panel-repair/pr-gifs-2026-10-31';portable=root/'plan/panel-repair/pr-gifs-portable-2026-10-31';portable.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='7005992d2083e36315be404603e438976857e65c'
p=r/'encode.py';text=p.read_text(encoding='utf-8-sig');text=text.replace("ROOT=Path('F:/photocraft');OUT=ROOT/'plan/panel-repair/pr-gifs-2026-10-31'","ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent");p.write_text(text,encoding='utf-8')
source={'head':head,'runtime_code':'88da5a9142c9c55bbb9fb93abe8ddc5192f83929','test_only_source_files':['crates/ui-egui/src/panels/panel_docking/presentation_demo.rs','crates/ui-egui/src/panels/panel_docking/pr_followup_replay.rs'],'runtime_changes':False}
(r/'source.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
demos=r/'demos';demos.mkdir(exist_ok=True)
for p in (root/'docs/images/panel-repair').iterdir():
 if p.suffix=='.gif' or p.name in ['LICENSE-MIT','LICENSE-APACHE','README.md']:shutil.copyfile(p,demos/p.name)
for name in ['RESULTS.json','gif-manifest.json','source.json','PR_STATUS.json','PR.md']:shutil.copyfile(r/name,portable/name)
readme='''# Расширенная галерея PR #10322 — 2026-10-31

PR: https://github.com/storytold/photocraft/pull/10322
Head: 7005992d2083e36315be404603e438976857e65c.

По просьбе пользователя добавлено 13 наглядных GIF без подписей: реальные движения мыши, фиксированное приближение рабочей области, паузы до и после действий. Галерея покрывает весь ремонт: компактные группы/flyout/отрыв, порядок вкладок, боковые доки, Tools целиком и resize по двум осям, независимые части, изменение ширины средней части, полный редактор рядом с компактным, нормальную высоту группы, нижний resize, строки над/под документом и вставку в свёрнутую строку. Указанная пользователем ссылка Before/after demonstrations and reproduction удалена из описания PR.

Гифки не содержат подписей или дорисованных состояний UI. PNG записаны текущим offscreen egui/WGPU harness; существующее кольцо показывает ввод. Это не native video и не FPS. Для публикации применены фиксированный crop, масштаб, общий 256-цветный GIF palette и паузы. Все декодированные кадры сравнены с соответствующими квантованными PNG; длительности/loop проверены. Изменения исходников ограничены test-only replay harness; продуктовый код не менялся.

Оба capture-прогона прошли, получено 887 сырых PNG. Панельный фильтр: 165 passed, 2 явных benchmark ignored. fmt прошёл. UI Clippy --no-deps сообщает только прежние пять расположений; новых замечаний к replay helper нет. Полный suite не повторялся для media/test-only изменения: ранее зафиксированные 4494 passed / 95 failed / 23 ignored относятся к runtime 88da5a914, а не объявляются результатом нового тестового состава.

Архивы:
- gif-review-package.zip: GIF, manifest, кодировщик, логи и описание PR.
- raw-pointer-replay.zip: все исходные кадры и метаданные.

Восстановить оба архива в plan/panel-repair/pr-gifs-2026-10-31. Для повторной записи: PHOTOCRAFT_PANEL_SHOWCASE + current_version_showcase; PHOTOCRAFT_PR_FOLLOWUP_REPLAY + pr_followup_pointer_replay. Затем python encode.py из каталога пакета (нужен Pillow). Скрипты публикации — журнал выполненной операции, их не следует запускать автоматически.

Галерея и test-only код сохранены в fork; PR остаётся Ready for review. Не создавать второй PR и не выполнять merge PR. Старые пакеты остаются историческими. Основной EXE собирает пользователь; агент его не собирал/не запускал. Новые коммиты только KotovGGG, About остаётся @KotovGGG. Не менять посторонние CI/ATN/PSD/action names/credits.
'''
(portable/'README_RU.md').write_text(readme,encoding='utf-8')
allfiles=sorted(p for p in r.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
groups={'raw-pointer-replay.zip':[p for p in allfiles if 'replay' in p.relative_to(r).parts[:1]],'gif-review-package.zip':[p for p in allfiles if 'replay' not in p.relative_to(r).parts[:1]]}
manifest={}
for name,files in groups.items():
 dest=portable/name
 with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:z.write(p,str(p.relative_to(r)).replace('\\','/'))
 with zipfile.ZipFile(dest) as z:assert z.testzip() is None
 assert dest.stat().st_size<95*1024*1024
 manifest[name]=hashlib.sha256(dest.read_bytes()).hexdigest()
 print(name,round(dest.stat().st_size/1024/1024,2),'MiB',len(files),'files')
(portable/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
