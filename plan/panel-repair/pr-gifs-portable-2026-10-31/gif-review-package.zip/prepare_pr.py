import sys,json
from pathlib import Path
sys.path.insert(0,'F:/photocraft/plan/panel-repair/pr-ready-2026-10-31')
from github_client import api
out=Path('F:/photocraft/plan/panel-repair/pr-gifs-2026-10-31')
pr=api('/repos/storytold/photocraft/pulls/10322')
assert pr['state']=='open' and not pr['draft'] and pr['head']['sha']=='d0e052e48434fa13f4ad60eebd20eb125bacac24'
(out/'pr-before.json').write_text(json.dumps(pr,indent=2)+'\n',encoding='utf-8')
body=pr['body'];start=body.index('<details>\n<summary>Latest regression demonstrations');end=body.index('</details>',start)+len('</details>')
groups=[('Docking and tab placement (5 GIFs)',[
 ('side-docking.gif','Dock a whole compact group on either side'),('compact-tab-order.gif','Insert and reorder compact tabs'),('below-document-tabs.gif','Dock below document tabs'),('attached-row-collapse.gif','Expand and collapse an attached row'),('attached-tab-insertion.gif','Insert before between and after attached tabs')]),
 ('Compact palettes and editor sizes (4 GIFs)',[
 ('group-flyout-detach.gif','Group palettes open a flyout and tear a panel off'),('independent-parts.gif','Collapse and expand neighbouring parts independently'),('full-editor-join-detach.gif','Keep editor height on join and detach'),('compact-group-height.gif','Restore normal group height')]),
 ('Resizing and Tools (4 GIFs)',[
 ('middle-part-width.gif','Resize only the middle part'),('floating-bottom-resize.gif','Resize the outer bottom corner and edge'),('vertical-divider.gif','Resize the vertical divider'),('tools-floating-resize.gif','Float resize and redock the whole Tools palette')])]
parts=['### Panel demonstrations — 13 GIFs\n\nRecorded pointer gestures, fixed close crops, and pauses around each action. No caption overlays.\n']
for title,clips in groups:
 parts.append('<details>\n<summary>'+title+'</summary>\n')
 for name,alt in clips:parts.append('\n!['+alt+'](https://raw.githubusercontent.com/KotovGGG/photocraft/__HEAD__/docs/images/panel-repair/'+name+')\n')
 parts.append('\n</details>\n')
parts.append('\nThese are offscreen replays with synthetic blank documents, not native desktop video or latency measurements. Provenance and licenses are adjacent to the assets.\n')
body=body[:start]+'\n'.join(parts)+body[end:]
body=body.replace('the final commit updates only documentation/assets.','later commits extend only the test-only replay harness and documentation/assets; runtime code is unchanged.')
body=body.replace('**164 panel tests**','**165 panel-filter tests** (including the new opt-in replay entry)')
body=body.replace('- **444 fresh offscreen PNGs**','- **13 caption-free gesture GIFs** are backed by 887 fresh replay frames. Both replay runs and decoded-pixel/timing checks passed.\n- **444 fresh offscreen PNGs**')
body=body.replace('/d0e052e48434fa13f4ad60eebd20eb125bacac24/','/__HEAD__/')
assert 'Before/after demonstrations and reproduction' not in body and 'panel-docking-demo.md' not in body
assert body.count('![')==13
(out/'PR-template.md').write_text(body,encoding='utf-8')
print('Prepared 13-GIF PR gallery; requested link is absent.')
