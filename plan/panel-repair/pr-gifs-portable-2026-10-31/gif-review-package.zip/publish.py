from pathlib import Path
import subprocess,sys,json
sys.path.insert(0,'F:/photocraft/plan/panel-repair/pr-ready-2026-10-31')
from github_client import api
r=Path('F:/photocraft/plan/panel-repair/pr-gifs-2026-10-31');head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='7005992d2083e36315be404603e438976857e65c'
pr=api('/repos/storytold/photocraft/pulls/10322')
assert pr['state']=='open' and not pr['draft'] and pr['head']['sha']==head and pr['head']['repo']['full_name']=='KotovGGG/photocraft'
body=(r/'PR-template.md').read_text(encoding='utf-8').replace('__HEAD__',head)
assert body.count('![')==13 and 'Before/after demonstrations and reproduction' not in body and 'panel-docking-demo.md' not in body
(r/'PR.md').write_text(body,encoding='utf-8')
updated=api('/repos/storytold/photocraft/pulls/10322','PATCH',{'body':body})
assert updated['body']==body and updated['draft'] is False
summary={'url':updated['html_url'],'head':updated['head']['sha'],'draft':updated['draft'],'state':updated['state'],'gif_count':updated['body'].count('!['),'removed_link_absent':'Before/after demonstrations and reproduction' not in updated['body']}
(r/'PR_STATUS.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
