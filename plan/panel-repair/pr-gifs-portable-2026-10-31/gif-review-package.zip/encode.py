from pathlib import Path
from PIL import Image,ImageChops,ImageOps
import json,math,hashlib,bisect
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;RAW=OUT/'replay';DEST=ROOT/'docs/images/panel-repair'
SCENES=[
 ('group-flyout-detach.gif','01-group-flyout-tearoff',0,None,(85,125,790,750)),
 ('compact-tab-order.gif','02-insert-redock',0,33,(85,130,520,430)),
 ('side-docking.gif','02-insert-redock',32,65,(0,60,1280,780)),
 ('vertical-divider.gif','03-expanded-stack-resize',0,25,(85,60,490,780)),
 ('below-document-tabs.gif','11-document-row',0,None,None),
 ('compact-group-height.gif','12-compact-height',0,None,None),
 ('floating-bottom-resize.gif','13-bottom-height',0,None,None),
 ('middle-part-width.gif','14-middle-width',0,None,None),
 ('independent-parts.gif','15-independent-parts',0,None,None),
 ('tools-floating-resize.gif','16-whole-tools',0,None,None),
 ('full-editor-join-detach.gif','17-full-join-detach',0,None,None),
 ('attached-row-collapse.gif','18-attached-tab-insertion',0,31,None),
 ('attached-tab-insertion.gif','18-attached-tab-insertion',30,103,None),
]
def old_durations(name,count):
 d=[100]*count;d[0]=1000;d[-1]=1600
 if name.startswith('01-'):press=[1,25];release=[10,34];rests=[16,24,40]
 elif name.startswith('02-'):press=[1,17,33,49];release=[10,26,42,58];rests=[16,32,48,64,72]
 else:press=[9];release=[18];rests=[8,24]
 for i in press:
  if i<count:d[i]=500
 for i in release:
  if i<count:d[i]=220
 for i in rests:
  if i<count:d[i]=1400
 return d
manifest=[]
for filename,folder,start,stop,box in SCENES:
 directory=RAW/folder;count=int((directory/'frame-count.txt').read_text());stop=count if stop is None else stop
 indices=list(range(start,stop));paths=[directory/f'{i:04}.png' for i in indices];size=Image.open(paths[0]).size
 if (directory/'frames.json').exists():
  metadata=json.loads((directory/'frames.json').read_text());assert len(metadata)==count
  rects=[r for frame in metadata[start:stop] for r in frame['focus_rects']]
  box=(max(0,math.floor(min(r[0] for r in rects))-20),max(0,math.floor(min(r[1] for r in rects))-20),min(size[0],math.ceil(max(r[2] for r in rects))+20),min(size[1],math.ceil(max(r[3] for r in rects))+20))
  durations=[m['duration_ms'] for m in metadata[start:stop]]
 else:durations=old_durations(folder,count)[start:stop]
 durations[0]=max(durations[0],1000);durations[-1]=max(durations[-1],1800)
 w,h=box[2]-box[0],box[3]-box[1];factor=min(1.5,1100/w,880/h);target=(round(w*factor),round(h*factor))
 def rgb(path):
  with Image.open(path) as im:return im.convert('RGB').crop(box).resize(target,Image.Resampling.LANCZOS)
 sample_indices=sorted(set(round(i*(len(paths)-1)/15) for i in range(16)))
 atlas=Image.new('RGB',(256*4,160*4))
 for n,i in enumerate(sample_indices):
  sample=ImageOps.contain(rgb(paths[i]),(256,160));atlas.paste(sample,((n%4)*256,(n//4)*160));sample.close()
 palette=atlas.quantize(colors=256,method=Image.Quantize.MEDIANCUT)
 frames=[rgb(path).quantize(palette=palette,dither=Image.Dither.FLOYDSTEINBERG) for path in paths]
 destination=DEST/filename
 frames[0].save(destination,save_all=True,append_images=frames[1:],duration=durations,loop=0,disposal=1,optimize=False)
 starts=[0]
 for d in durations:starts.append(starts[-1]+d)
 elapsed=0;decoded=0
 with Image.open(destination) as gif:
  assert gif.info.get('loop')==0
  while True:
   expected=min(len(frames)-1,bisect.bisect_right(starts,elapsed)-1)
   actual=gif.convert('RGB'); reference=frames[expected].convert('RGB')
   assert ImageChops.difference(actual,reference).getbbox() is None,(filename,decoded,expected)
   elapsed+=gif.info.get('duration',0);decoded+=1
   try:gif.seek(gif.tell()+1)
   except EOFError:break
 assert elapsed==sum(durations),(filename,elapsed,sum(durations))
 manifest.append({'gif':filename,'source':folder,'source_indices':[start,stop],'source_frame_count':len(frames),'encoded_frame_count':decoded,'duration_ms':elapsed,'crop':box,'output_size':target,'source_sha256':[hashlib.sha256(path.read_bytes()).hexdigest() for path in paths],'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'bytes':destination.stat().st_size,'captions':False,'decoded_pixels_verified':True})
 print(f'{filename}: {decoded} frames, {elapsed/1000:.1f}s, {target}, {destination.stat().st_size/1024:.0f} KiB',flush=True)
 for frame in frames:frame.close()
 palette.close();atlas.close()
(OUT/'gif-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
