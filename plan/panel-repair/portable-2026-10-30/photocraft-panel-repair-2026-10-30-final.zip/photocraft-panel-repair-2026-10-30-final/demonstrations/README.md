# Deterministic panel demonstrations

Fresh offscreen egui/WGPU pointer replay of the current C-worktree, not a native desktop recording.
The first thirteen clips preserve the actual replay frames; the two final clips show the last reviewed transitions at settled states (1200ms/state). The landing clip uses recorded 0/50/150/300ms frame timestamps. Other replay frames use60ms display time with a1000ms final hold; these GIF durations are presentation timing, not frame-performance measurements.

Sources, frame counts and display timing are in manifest.json; raw capture hashes are in the package's capture-manifest.json. UI assets retain project licenses; synthetic scenes contain no personal photographs. MIT OR Apache-2.0.
