# PhotoCraft: финальный пакет ремонта панелей

Дата:2026-10-30. Ветка:codex/panel-layout-upstream.
Base:382b047c30483024159aaa63831947bc99a5e28b; HEAD:cd571efe41c556347b1851ac208e3388acc3002e; автор:@KotovGGG.

Пакет собран заново после визуальной матрицы. PR.md — описание; panel-repair.patch
содержит полный diff относительно актуального upstream main, включая явный snapshot
craft-ui. ACCEPTANCE_RU.md перечисляет приёмку и ограничения. checks/ содержит логи;
136 панельных и346 shared docking тестов прошли. Полный UI suite не зелёный, его
сбои выделены отдельно. Основной exe не собирался. Исходники и профиль старого
D:/photocraft не менялись; общий target использован только для проверок.

demonstrations/:15 новых GIF, включая13 pointer replay и2 финальных перехода.
final-review-captures/:132 новых PNG и fitted rect JSON; весь570+515 capture run
проверяется по capture-manifest.json, остальные исходные кадры лежат рядом с пакетом
в2026-10-30-final-2/. problem-layout/:снимки сохранённой проблемной раскладки.
Исходные пользовательские снимки последних замечаний остаются в локальном evidence;
в пакете только необходимые cropped before/after с лицензиями и происхождением.

Исторические ZIP и предыдущие capture manifests не являются этим пакетом.
Живые native/physical mixed-DPI/monitor/IME проверки остаются за пользовательской сборкой.
