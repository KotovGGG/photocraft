from pathlib import Path
import subprocess,json,hashlib,shutil,zipfile

root=Path.cwd(); out=root/'plan/panel-repair/2026-10-30-final-2'
package=root/'plan/panel-repair/photocraft-panel-repair-2026-10-30-final'
package.mkdir() # Never reuse an old proposal archive.
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
body=(out/'PR.template.md').read_text(encoding='utf-8').replace('VALIDATION',(out/'validation-body.md').read_text(encoding='utf-8').strip()).replace('COMMIT',head)
(out/'PR.md').write_text(body,encoding='utf-8'); (package/'PR.md').write_text(body,encoding='utf-8')
(package/'panel-repair.patch').write_bytes(subprocess.check_output(['git','diff','--binary','origin/main','HEAD']))
for n in ['ACCEPTANCE_RU.md','results.json','source-fingerprint.json','capture-manifest.json','capture-counts.json','active-performance.json','gate-root.json','scope.json','full-ui-classification.json','demo-crops.json','final-transition-review.png','final-dpi-review.png']:
    copy(out/n,package/n)
for p in sorted(out.glob('*.log')):
    if p.name not in ['post-merge-panel.log']: copy(p,package/'checks'/p.name)
for p in (root/'docs/images/panel-repair').iterdir():
    if p.is_file(): copy(p,package/'docs/images/panel-repair'/p.name)
for p in (out/'demonstrations').iterdir():
    if p.is_file(): copy(p,package/'demonstrations'/p.name)
for p in (out/'final-review-captures').iterdir():
    if p.is_file(): copy(p,package/'final-review-captures'/p.name)
for p in sorted((out/'audit-captures').glob('problem*')):
    copy(p,package/'problem-layout'/p.name)
for n in ['panel-docking-contract.md','panel-docking-demo.md','panel-docking-validation.md']:
    copy(root/'docs'/n,package/'docs'/n)
(package/'README_RU.md').write_text(f'''# PhotoCraft: финальный пакет ремонта панелей

Дата:2026-10-30. Ветка:codex/panel-layout-upstream.
Base:{base}; HEAD:{head}; автор:@KotovGGG.

Пакет собран заново после визуальной матрицы. PR.md — описание; panel-repair.patch
содержит полный diff относительно актуального upstream main, включая явный snapshot
craft-ui. ACCEPTANCE_RU.md перечисляет приёмку и ограничения. checks/ содержит логи;
136 панельных и346 shared docking тестов прошли. Полный UI suite не зелёный, его
сбои выделены отдельно. Основной exe не собирался. Исходники и профиль старого
D:/photocraft не менялись; общий target использован только для проверок.

demonstrations/:15 новых GIF, включая13 pointer replay и2 финальных перехода.
final-review-captures/:132 новых PNG и fitted rect JSON; весь570+515 capture run
проверяется по capture-manifest.json, остальные исходные кадры лежат рядом с пакетом
в2026-10-30-final-2/. problem-layout/:снимки сохранённой проблемной раскладки.
Исходные пользовательские снимки последних замечаний остаются в локальном evidence;
в пакете только необходимые cropped before/after с лицензиями и происхождением.

Исторические ZIP и предыдущие capture manifests не являются этим пакетом.
Живые native/physical mixed-DPI/monitor/IME проверки остаются за пользовательской сборкой.
''',encoding='utf-8')
manifest={'base':base,'head':head,'author':'KotovGGG','files':[{'path':str(p.relative_to(package)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(package.rglob('*')) if p.is_file()]}
(package/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
archive=package.with_suffix('.zip')
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(package.rglob('*')):
        if p.is_file(): z.write(p,str(p.relative_to(package.parent)))
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
(out/'package.json').write_text(json.dumps({'directory':str(package),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'head':head},indent=2)+'\n')
print(str(archive));print(sha(archive))
