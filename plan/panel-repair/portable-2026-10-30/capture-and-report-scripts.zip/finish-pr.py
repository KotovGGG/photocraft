from pathlib import Path
import os,subprocess,json,re,sys
root=Path.cwd();out=root/'plan/panel-repair/2026-10-30-final-2';env=os.environ.copy();env.update(CARGO_TARGET_DIR='D:/photocraft/target',CARGO_BUILD_JOBS='1');results={}
def run(name,args,extra=None,allow_fail=False):
 e=env.copy();e.update(extra or {})
 with (out/(name+'.log')).open('w',encoding='utf-8') as f:r=subprocess.run([str(a) for a in args],env=e,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 results[name]=r.returncode;(out/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8');print(name,r.returncode,flush=True)
 if r.returncode and not allow_fail:sys.exit(r.returncode)
 return r.returncode
run('format',['cargo','fmt','--all','--','--check'])
run('panel-tests',['cargo','test','-p','photocraft-ui-egui','--lib','panel_docking','--','--nocapture'])
log=(out/'panel-tests.log').read_text(encoding='utf-8');match=re.search(r'Running unittests[^\n]*\(([^\n]+\.exe)\)',log);assert match,log[-2000:];exe=Path(match[1].replace('\\','/'));assert exe.name.startswith('photocraft_ui_egui-')
(out/'test-binary-path.txt').write_text(str(exe),encoding='utf-8')
for filt in ['panel_dependency_contract','dock::tests','workspace','toolbar','panel_visibility','overflow']:
 run('related-'+filt.replace('::','-'),[exe,filt,'--nocapture'])
run('engine-tests',['cargo','test','-p','photocraft-engine','--lib','--tests','--','--test-threads=4'])
run('engine-panic-hunt',['cargo','test','-p','photocraft-engine','--test','panic_hunt','--','--ignored','--test-threads=4'])
run('ui-engine-clippy',['cargo','clippy','-p','photocraft-ui-egui','-p','photocraft-engine','--all-targets','--','-D','warnings'])
isolated=Path('D:/photocraft/target/panel-repair-xtask-c-worktree');run('xtask-build',['cargo','build','-p','xtask','--target-dir',isolated]);xtask=isolated/'debug/xtask.exe'
for command in ['layers','wasm','parity','scorecard']:run(command,[xtask,command])
run('craft-clippy',['cargo','clippy','-p','craft-ui','--lib','--','-D','warnings'])
run('craft-tests',['cargo','test','--manifest-path','vendor/craft-ui/Cargo.toml','--config','vendor/craft-ui/tests-config.toml','--features','serde,native-windows,screen-testing','--lib','docking::'])
for name,filt,extra in [
 ('final-review-visual','capture_final_review_transitions',{'PHOTOCRAFT_FINAL_REVIEW_CAPTURES':str(out/'final-review-captures')}),
 ('seam-visual','capture_fourth_review_seams',{'PHOTOCRAFT_FOURTH_REVIEW_CAPTURES':str(out/'seam-captures')}),
 ('corner-visual','capture_compact_corner_silhouette',{'PHOTOCRAFT_CORNER_CAPTURES':str(out/'corner-captures')}),
 ('audit-visual','repair_audit_captures',{'PHOTOCRAFT_REPAIR_LAYOUT':'D:/photocraft/plan/panel-repair-handoff-2026-10-29/evidence/saved-panel-layout.json','PHOTOCRAFT_REPAIR_CAPTURES':str(out/'audit-captures')}),
 ('port-visual','capture_port_chrome_at_multiple_scales',{'PHOTOCRAFT_PANEL_PORT_FIXTURES':str(out/'port-captures')}),
 ('replay','current_version_showcase',{'PHOTOCRAFT_PANEL_SHOWCASE':str(out/'replay')})]:run(name,[exe,filt,'--nocapture'],extra)
for n in range(1,6):run('active-current-'+str(n),[exe,'benchmark_panel_hover_and_drag_frames','--ignored','--nocapture'])
run('full-ui-tests',['cargo','test','-p','photocraft-ui-egui','--lib','--tests','--','--test-threads=4'],allow_fail=True)
