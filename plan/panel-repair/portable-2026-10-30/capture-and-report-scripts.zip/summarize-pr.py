from pathlib import Path
import hashlib, json, subprocess, re, statistics

root=Path.cwd(); out=root/'plan/panel-repair/2026-10-30-final-2'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,value): (out/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def git(*args): return subprocess.check_output(['git',*args],text=True,encoding='utf-8').strip()

old=json.loads((out/'core-before-gates.json').read_text())
assert all(sha(root/f['path'])==f['sha256'] for f in old['files']), 'Source changed during gates'
exe=Path((out/'test-binary-path.txt').read_text().strip())
dump('source-fingerprint.json',dict(base=old['base'],head=git('rev-parse','HEAD'),files=old['files'],
     binary=str(exe),binarySha256=sha(exe),coreUnchangedDuringGates=True))

caps=[]
for folder in ['final-review-captures','seam-captures','corner-captures','audit-captures','port-captures','replay']:
    files=sorted((out/folder).rglob('*'))
    caps.extend({'path':str(p.relative_to(out)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files if p.is_file())
dump('capture-manifest.json',caps)
counts={folder:sum(1 for p in caps if p['path'].startswith(folder+'/') and p['path'].endswith('.png')) for folder in ['final-review-captures','seam-captures','corner-captures','audit-captures','port-captures','replay']}
dump('capture-counts.json',counts)

vend=root/'vendor/craft-ui'; upstream=Path('C:/Users/pavel/.cargo/git/checkouts/craft-libs-d830b991a08c6c3d/92d392c/crates/ui')
mods=[str(p.relative_to(vend)).replace('\\','/') for p in sorted((vend/'src').rglob('*.rs')) if p.read_text(encoding='utf-8')!=(upstream/p.relative_to(vend)).read_text(encoding='utf-8')]
protected=git('diff','--name-only','origin/main','--','.github','contributors','crates/psd','crates/io','crates/codecs','crates/format')
assert not protected,protected
candidate_files=set(git('diff','--name-only','origin/main').splitlines()+git('ls-files','--others','--exclude-standard').splitlines())
fonts=[p for p in candidate_files if Path(p).suffix.lower() in ['.ttf','.otf','.woff','.woff2']]
assert not fonts,fonts
x='5.0 * scale + 0.35'; assert x in (root/'crates/ui-egui/src/panels/panel_docking.rs').read_text()
dump('scope.json',dict(vendorRustChanges=mods,nonIgnoredFontBinaries=fonts,protectedPathsDiff=[],xHalf=x,
     mainExe='not built or launched',oldForkSource='not modified; shared target only',
     authors=git('log','origin/main..HEAD','--format=%an').splitlines()))
assert len(mods)==6,mods
xtask=Path('D:/photocraft/target/panel-repair-xtask-c-worktree/debug/xtask.exe')
wasm=(out/'wasm.log').read_text(encoding='utf-8')
assert 'C:\\Users\\pavel\\.codex\\worktrees\\panel-layout-upstream\\photocraft\\crates\\ui-egui' in wasm
dump('gate-root.json',dict(root=str(root),xtaskBinary=str(xtask),sha256=sha(xtask),
     compileTimeRoot='C-worktree isolated target; see xtask-build.log and wasm.log',gates=['layers','wasm','parity','scorecard']))

perf=[]
for n in range(1,6):
    s=(out/f'active-current-{n}.log').read_text(encoding='utf-8')
    m=re.search(r'ACTIVE_PANEL_BENCH (\{[^\n]+\})',s); assert m
    perf.append({'run':n,'phases':json.loads(m[1])})
med={phase:{key:statistics.median(r['phases'][phase][key] for r in perf) for key in ['p50_us','p95_us','p99_us']} for phase in ['idle','hover','drag']}
for phase in med: med[phase]['max_us']=max(r['phases'][phase]['max_us'] for r in perf)
dump('active-performance.json',dict(method='Five current-code CPU runs; 1280x800 at125%, no document/GPU;600 measured frames/phase/run,40 warmup. Not native GPU/FPS or a before/after comparison.',binarySha256=sha(exe),runs=perf,medianPercentiles=med))

full=(out/'full-ui-tests.log').read_text(encoding='utf-8')
failed=sorted(set(re.findall(r'^    ((?:[a-zA-Z_][\w]*::)+[\w]+)$',full,re.M)))
previous=json.loads((root/'plan/panel-repair/baseline-comparison.json').read_text(encoding='utf-8'))
known={x['test'] for x in previous if x.get('baseline_exit')==101}
dump('full-ui-classification.json',dict(summaries=re.findall(r'^test result:.*$',full,re.M),failed=failed,
     alreadyFailedInRecordedBaseline=[t for t in failed if t in known],notInRecordedBaseline=[t for t in failed if t not in known],
     baselineEvidence='plan/panel-repair/baseline-comparison.json; historical baseline, not a fresh current-main full run'))
print(json.dumps({'captureCounts':counts,'medianCpu':med,'fullFailures':len(failed),'unclassified':len([t for t in failed if t not in known])},indent=2))
