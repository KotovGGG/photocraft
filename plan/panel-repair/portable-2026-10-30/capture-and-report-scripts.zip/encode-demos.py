from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
import json, math

out=Path.cwd()/'plan/panel-repair/2026-10-30-final-2'
dest=out/'demonstrations'; dest.mkdir(exist_ok=True)
def encode(paths,target,durations):
    frames=[]
    for p in paths:
        with Image.open(p) as source:
            im=ImageOps.contain(source.convert('RGB'),(1280,800))
            frames.append(im.quantize(colors=128,method=Image.Quantize.FASTOCTREE))
    frames[0].save(target,save_all=True,append_images=frames[1:],duration=durations,loop=0,disposal=2,optimize=False)
    for im in frames: im.close()

manifest=[]
for folder in sorted((out/'replay').iterdir()):
    if not folder.is_dir() or not (folder/'frame-count.txt').exists(): continue
    count=int((folder/'frame-count.txt').read_text()); paths=[folder/f'{n:04}.png' for n in range(count)]
    durations=[60]*count; durations[-1]=1000
    if (folder/'timestamps-ms.json').exists():
        stamps=json.loads((folder/'timestamps-ms.json').read_text())
        durations=[b-a for a,b in zip(stamps,stamps[1:])]+[1000]
        assert len(durations)==count
    target=dest/(folder.name+'.gif'); encode(paths,target,durations)
    manifest.append({'gif':target.name,'source':str(folder.relative_to(out)),'frames':count,'durationsMs':durations})

for name,states in [
    ('11-full-join-detach',['full-before-join','full-joined-to-mini','full-detached']),
    ('12-top-attached-tabs',['top-collapsed','top-expanded','top-recollapsed','top-added-tab','top-between-preview','top-between-inserted','top-tabs-expanded','top-tabs-collapsed']),
]:
    paths=[out/'final-review-captures'/f'pro-1.25-{s}.png' for s in states]
    target=dest/(name+'.gif'); encode(paths,target,[1200]*len(paths))
    manifest.append({'gif':target.name,'source':'final-review-captures/pro-1.25-*','states':states,'frames':len(paths),'durationsMs':[1200]*len(paths)})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'README.md').write_text('''# Deterministic panel demonstrations

Fresh offscreen egui/WGPU pointer replay of the current C-worktree, not a native desktop recording.
The first thirteen clips preserve the actual replay frames; the two final clips show the last reviewed transitions at settled states (1200ms/state). The landing clip uses recorded 0/50/150/300ms frame timestamps. Other replay frames use60ms display time with a1000ms final hold; these GIF durations are presentation timing, not frame-performance measurements.

Sources, frame counts and display timing are in manifest.json; raw capture hashes are in the package's capture-manifest.json. UI assets retain project licenses; synthetic scenes contain no personal photographs. MIT OR Apache-2.0.
''',encoding='utf-8')
print(f'Encoded {len(manifest)} GIFs from current capture run')
