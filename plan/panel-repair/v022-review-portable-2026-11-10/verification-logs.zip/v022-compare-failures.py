import concurrent.futures, hashlib, json, pathlib, subprocess, sys
root=pathlib.Path("F:/photocraft/plan/panel-repair")
names=json.loads((root/"v022-failed-test-names.json").read_text())
exe=sys.argv[1]
label=sys.argv[2]
cwd=sys.argv[3]
logs=root/("v022-"+label+"-failures");logs.mkdir(exist_ok=True)
def run(name):
 try:
  r=subprocess.run([exe,name,"--exact","--nocapture"],cwd=cwd,capture_output=True,timeout=120)
  text=(r.stdout+r.stderr).decode("utf-8",errors="replace")
  code=r.returncode
 except subprocess.TimeoutExpired as e:
  text=str(e);code=124
 key=hashlib.sha256(name.encode()).hexdigest()[:12]+".log"
 (logs/key).write_text(text,encoding="utf-8")
 result={"test":name,"exit":code,"missing":"running 0 tests" in text,"log":key}
 print(json.dumps(result),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(run,names))
(root/("v022-"+label+"-failure-comparison.json")).write_text(json.dumps(results,indent=2),encoding="utf-8")
print(json.dumps({"passed":sum(x["exit"]==0 and not x["missing"] for x in results),"failed":sum(x["exit"]!=0 for x in results),"missing":sum(x["missing"] for x in results)}))
