"""Package this checkout's new evidence separately from the historical handoff."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path.cwd().resolve()
if not (ROOT / "Cargo.toml").is_file():
    raise RuntimeError("Run from the PhotoCraft repository root")
OUT = ROOT / "plan/panel-repair/home-2026-10-30"
DEST = ROOT / "plan/panel-repair/handoff-worktree/plan/panel-repair/home-portable-2026-10-30"
DEST.mkdir(parents=True, exist_ok=True)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
upstream = subprocess.check_output(["git", "rev-parse", "upstream/main"], cwd=ROOT, text=True).strip()
(OUT / "panel-layout.patch").write_bytes(subprocess.check_output(
    ["git", "diff", "--binary", "upstream/main", "HEAD"], cwd=ROOT))
manifest = []
for directory in ["final-review-captures", "seam-captures", "corner-captures",
                  "audit-captures", "port-captures", "replay"]:
    files = sorted(p for p in (OUT / directory).rglob("*") if p.is_file())
    assert files, directory
    with zipfile.ZipFile(DEST / (directory + ".zip"), "w", zipfile.ZIP_DEFLATED) as archive:
        for file in files:
            archive.write(file, file.relative_to(OUT).as_posix())
            manifest.append({"path": file.relative_to(OUT).as_posix(), "bytes": file.stat().st_size,
                             "sha256": hashlib.sha256(file.read_bytes()).hexdigest()})
(OUT / "capture-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", "utf-8")

with zipfile.ZipFile(DEST / "reports-and-demonstrations.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(OUT.iterdir()):
        if p.is_file():
            archive.write(p, p.name)
    for name in ["demonstrations", "review-crops"]:
        for p in sorted((OUT / name).rglob("*")):
            if p.is_file():
                archive.write(p, p.relative_to(OUT).as_posix())
    for name in ["verify-home.py", "home-review-assets.py", "home-encode-demos.py", "package-home.py"]:
        archive.write(ROOT / "plan/panel-repair" / name, "scripts/" + name)
    for name in ["home-panel-tests.log", "home-panel-tests.exit"]:
        archive.write(ROOT / "plan/panel-repair" / name, name)
    for p in sorted((ROOT / "docs/images/panel-repair").iterdir()):
        if p.is_file():
            archive.write(p, "docs-images/" + p.name)

for name in ["README_RU.md", "LATEST_UPSTREAM_RU.md", "ACCEPTANCE_RU.md", "PR.md", "results.json", "full-ui-classification.json"]:
    shutil.copy2(OUT / name, DEST / name)
entries = []
for p in sorted(DEST.iterdir()):
    if p.is_file() and p.name != "manifest.json":
        assert p.stat().st_size < 95_000_000, p.name
        entries.append({"path": p.name, "bytes": p.stat().st_size,
                        "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
(DEST / "manifest.json").write_text(json.dumps({
    "sourceCommit": head, "upstreamCommit": upstream, "pr": "https://github.com/storytold/photocraft/pull/10322",
    "state": "Draft; native contributor acceptance pending; full UI has documented failures",
    "files": entries
}, indent=2) + "\n", "utf-8")
print("Packaged", len(entries), "files;", len(manifest), "raw capture/metadata files; source", head)
