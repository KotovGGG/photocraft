"""Local, resumable validation of the restored panel branch (no product EXE build)."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path.cwd().resolve()
if not (ROOT / "Cargo.toml").is_file():
    raise RuntimeError("Run from the PhotoCraft repository root")
OUT = ROOT / "plan/panel-repair/home-2026-10-30"
OUT.mkdir(parents=True, exist_ok=True)
ENV = os.environ.copy()
ENV["PATH"] = str(Path.home() / ".cargo/bin") + os.pathsep + ENV["PATH"]
ENV["CARGO_TARGET_DIR"] = str(ROOT / "target")
ENV["CARGO_BUILD_JOBS"] = "2"
ENV["PYTHONIOENCODING"] = "utf-8"
RESULTS_PATH = OUT / "results.json"
RESULTS = json.loads(RESULTS_PATH.read_text("utf-8")) if RESULTS_PATH.exists() else {}


def run(name, args, extra=None, allow_failure=False):
    env = ENV | (extra or {})
    command = [str(arg) for arg in args]
    command[0] = shutil.which(command[0], path=env["PATH"]) or command[0]
    with (OUT / (name + ".log")).open("w", encoding="utf-8") as log:
        result = subprocess.run(command, cwd=ROOT, env=env,
                                stdout=log, stderr=subprocess.STDOUT)
    record = {"exit": result.returncode, "command": [str(arg) for arg in args]}
    (OUT / (name + ".result.json")).write_text(json.dumps(record, indent=2) + "\n", "utf-8")
    current = json.loads(RESULTS_PATH.read_text("utf-8")) if RESULTS_PATH.exists() else {}
    current[name] = record
    pending = RESULTS_PATH.with_name("results-" + str(os.getpid()) + ".tmp")
    pending.write_text(json.dumps(current, indent=2) + "\n", "utf-8")
    pending.replace(RESULTS_PATH)
    print(name, "exit", result.returncode, flush=True)
    if result.returncode and not allow_failure:
        print((OUT / (name + ".log")).read_text("utf-8", errors="replace")[-5000:], flush=True)
        sys.exit(result.returncode)


def test_binary():
    fingerprint = OUT / "source-before-validation.json"
    if fingerprint.exists():
        reviewed = json.loads(fingerprint.read_text("utf-8"))["files"]
        changed = [name for name, sha in reviewed.items()
                   if not (ROOT / name).is_file() or hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != sha]
        if changed:
            raise RuntimeError("Sources changed: rebuild the panel test binary and refresh the source manifest before replay")
    log = (ROOT / "plan/panel-repair/home-panel-tests.log").read_text("utf-8", errors="replace")
    match = re.search(r"Running unittests[^\n]*\(([^\n]+\.exe)\)", log)
    if not match:
        raise RuntimeError("Initial panel test build has not completed")
    exe = ROOT / match[1]
    (OUT / "test-binary.json").write_text(json.dumps({
        "path": str(exe), "sha256": hashlib.sha256(exe.read_bytes()).hexdigest()
    }, indent=2) + "\n", "utf-8")
    return exe


stage = sys.argv[1]
if stage == "related":
    exe = test_binary()
    for filt in ["panel_dependency_contract", "dock::tests", "workspace", "toolbar",
                 "type_flyout_tests", "panel_visibility", "overflow"]:
        run("related-" + filt.replace("::", "-"), [exe, filt, "--nocapture", "--test-threads=4"])
    run("workspace-integration", ["cargo", "test", "--locked", "-p", "photocraft-ui-egui",
                                  "--test", "it", "workspace", "--", "--test-threads=4"])
elif stage == "gates":
    run("format", ["cargo", "fmt", "--all", "--", "--check"])
    run("engine-tests", ["cargo", "test", "--locked", "-p", "photocraft-engine",
                         "--lib", "--tests", "--", "--test-threads=4"])
    run("engine-panic-hunt", ["cargo", "test", "--locked", "-p", "photocraft-engine",
                              "--test", "panic_hunt", "--", "--ignored", "--test-threads=4"])
    run("ui-engine-clippy", ["cargo", "clippy", "--locked", "-p", "photocraft-ui-egui",
                             "-p", "photocraft-engine", "--all-targets", "--", "-D", "warnings"])
    run("xtask-build", ["cargo", "build", "--locked", "-p", "xtask"])
    xtask = ROOT / "target/debug/xtask.exe"
    for command in ["layers", "wasm", "parity", "scorecard"]:
        run(command, [xtask, command])
    run("doctests", ["cargo", "test", "--locked", "-p", "photocraft-ui-egui",
                      "-p", "photocraft-engine", "--doc"])
    run("craft-clippy", ["cargo", "clippy", "--locked", "-p", "craft-ui", "--lib", "--", "-D", "warnings"])
elif stage == "shared":
    run("craft-tests", ["cargo", "test", "--manifest-path", "vendor/craft-ui/Cargo.toml",
                         "--config", "vendor/craft-ui/tests-config.toml", "--features",
                         "serde,native-windows,screen-testing", "--lib", "docking::"])
elif stage == "remaining":
    run("ui-engine-clippy-no-deps", ["cargo", "clippy", "--locked", "--no-deps", "-p", "photocraft-ui-egui",
                                     "-p", "photocraft-engine", "--all-targets", "--", "-D", "warnings"], allow_failure=True)
    run("xtask-build", ["cargo", "build", "--locked", "-p", "xtask"])
    xtask = ROOT / "target/debug/xtask.exe"
    for command in ["layers", "wasm", "parity", "scorecard"]:
        run(command, [xtask, command], allow_failure=True)
    run("doctests", ["cargo", "test", "--locked", "-p", "photocraft-ui-egui",
                      "-p", "photocraft-engine", "--doc"], allow_failure=True)
    run("craft-clippy", ["cargo", "clippy", "--locked", "-p", "craft-ui", "--lib", "--", "-D", "warnings"], allow_failure=True)
elif stage == "visual":
    exe = test_binary()
    audit = ROOT / "plan/panel-repair/portable-2026-10-30/extracted/original-audit-and-ui-inputs/original-audit/evidence/saved-panel-layout.json"
    for name, filt, variables in [
        ("final-review", "capture_final_review_transitions", {"PHOTOCRAFT_FINAL_REVIEW_CAPTURES": str(OUT / "final-review-captures")}),
        ("seam", "capture_fourth_review_seams", {"PHOTOCRAFT_FOURTH_REVIEW_CAPTURES": str(OUT / "seam-captures")}),
        ("corner", "capture_compact_corner_silhouette", {"PHOTOCRAFT_CORNER_CAPTURES": str(OUT / "corner-captures")}),
        ("audit", "repair_audit_captures", {"PHOTOCRAFT_REPAIR_LAYOUT": str(audit), "PHOTOCRAFT_REPAIR_CAPTURES": str(OUT / "audit-captures")}),
        ("port", "capture_port_chrome_at_multiple_scales", {"PHOTOCRAFT_PANEL_PORT_FIXTURES": str(OUT / "port-captures")}),
        ("replay", "current_version_showcase", {"PHOTOCRAFT_PANEL_SHOWCASE": str(OUT / "replay")}),
    ]:
        run("visual-" + name, [exe, filt, "--nocapture", "--test-threads=1"], variables)
elif stage == "full-unit":
    run("full-ui-unit-tests", [test_binary(), "--test-threads=4"], allow_failure=True)
elif stage == "ui-clippy":
    run("ui-clippy-no-deps", ["cargo", "clippy", "--locked", "--no-deps", "-p", "photocraft-ui-egui",
                              "--all-targets", "--", "-D", "warnings"], allow_failure=True)
elif stage == "full":
    run("full-ui-tests", ["cargo", "test", "--locked", "-p", "photocraft-ui-egui",
                          "--lib", "--tests", "--", "--test-threads=4"], allow_failure=True)
else:
    raise ValueError(stage)
