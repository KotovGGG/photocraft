from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
import json, math

root = Path.cwd()
out = root / 'plan/panel-repair/home-2026-10-30'
caps = out / 'final-review-captures'
assets = out / 'review-crops'
assets.mkdir(exist_ok=True)

def crop_panels(stem, names, pad=2, below=0):
    meta = json.loads((caps / (stem + '.json')).read_text())
    im = Image.open(caps / (stem + '.png')).convert('RGB')
    rects = [meta['panels'][n] for n in names if n in meta['panels']]
    assert rects, (stem, names)
    s = meta['scale']
    box = (max(0, math.floor(min(r[0] for r in rects)*s)-pad),
           max(0, math.floor(min(r[1] for r in rects)*s)-pad),
           min(im.width, math.ceil(max(r[0]+r[2] for r in rects)*s)+pad),
           min(im.height, math.ceil(max(r[1]+r[3] for r in rects)*s)+pad+below))
    return im.crop(box), {'source': stem + '.png', 'logicalPanels': names, 'physicalCrop': box}

crop_meta = {}
for stem, names, filename, below in [
    ('pro-1.25-full-joined-to-mini', ['brushes', 'color'], 'full-height-after.png', 0),
    ('pro-1.25-top-recollapsed', ['history'], 'top-collapse-after.png', 60),
]:
    im, details = crop_panels(stem, names, below=below)
    im.save(assets / filename)
    crop_meta[filename] = details
(out / 'demo-crops.json').write_text(json.dumps(crop_meta, indent=2) + '\n')

states = ['full-before-join', 'full-joined-to-mini', 'full-detached', 'top-collapsed',
          'top-expanded', 'top-recollapsed', 'top-added-tab', 'top-between-preview',
          'top-between-inserted', 'top-tabs-expanded', 'top-tabs-collapsed']

def make_grid(items, path, cols=3, w=460, h=310):
    grid = Image.new('RGB', (cols*w, math.ceil(len(items)/cols)*h), '#d5d5d5')
    d = ImageDraw.Draw(grid)
    for i,(title,im) in enumerate(items):
        x,y=(i%cols)*w,(i//cols)*h
        d.text((x+6,y+5), title, fill='black')
        thumb = ImageOps.contain(im, (w-12,h-30))
        grid.paste(thumb,(x+6,y+25))
    grid.save(path)

items=[]
for state in states:
    for theme in ['pro','proMedium','proLight']:
        stem=f'{theme}-1.25-{state}'
        names=['brushes','color'] if state.startswith('full') else ['history']
        if state in ['top-added-tab','top-between-preview','top-between-inserted','top-tabs-expanded','top-tabs-collapsed']:
            meta=json.loads((caps/(stem+'.json')).read_text())
            names=[n for n in ['history','color','brushes'] if n in meta['panels']]
        im,_=crop_panels(stem,names,pad=4,below=15)
        items.append((stem,im))
make_grid(items,out/'final-transition-review.png')

items=[]
for state in ['full-joined-to-mini','top-recollapsed','top-between-inserted']:
    for scale in ['1','1.25','1.5','2']:
        stem=f'pro-{scale}-{state}'
        names=['brushes','color'] if state.startswith('full') else ['history']
        im,_=crop_panels(stem,names,pad=4,below=12)
        items.append((stem,im))
make_grid(items,out/'final-dpi-review.png',cols=4,w=400,h=300)
print(json.dumps(crop_meta,indent=2))
