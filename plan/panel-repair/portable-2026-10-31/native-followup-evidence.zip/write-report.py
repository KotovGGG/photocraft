from pathlib import Path
import json,re
root=Path('F:/photocraft/plan/panel-repair/native-followup-2026-10-31')
checks=json.loads((root/'verification-results.json').read_text())
required=['all-panels','shared','workspace-integration','native-matrix','desktop-matrix','seam-matrix','final-transitions','panic-hunt','desktop-check','wasm','layers','fmt','active-panel-benchmark','discard-pass']
for label in required:
    if checks.get(label,{}).get('exit') != 0:
        raise SystemExit(f'Unfinished or failing gate: {label}')
classification=json.loads((root/'full-ui-classification.json').read_text())
if classification['new_failures'] or classification['removed_failures'] or len(classification['failed'])!=95:
    raise SystemExit('Review the full UI failure comparison before publishing results')
bench_log=(root/'active-panel-benchmark.log').read_text(encoding='utf-8',errors='replace')
bench=json.loads(re.search(r'ACTIVE_PANEL_BENCH (\{[^\n]+\})',bench_log).group(1))
(root/'active-panel-benchmark.json').write_text(json.dumps(bench,indent=2)+'\n',encoding='utf-8')
bench_rows='\n'.join(f'| {name} | {bench[name]["p50_us"]/1000:.3f} | {bench[name]["p95_us"]/1000:.3f} |' for name in ['idle','hover','drag'])
visuals=list((root/'matrix').glob('*.png'))+list((root/'previous-matrix').glob('*.png'))
if len(visuals)!=444:
    raise SystemExit(f'Expected 444 rendered PNG, got {len(visuals)}')
text=f'''# Повторный ремонт панелей PhotoCraft v0.18.0 — 2026-10-31

Код: `f8c0c4a7204bf499e906c2fd978bba06aa512636`, автор KotovGGG.
Основа: `621d9238b7f8ccc31def22a2572615cb40143056`; release v0.18.0 — `8a87a457abb43ac344deeb3fdb67541b91a72ff1`.
Код сохранён: https://github.com/KotovGGG/photocraft/tree/codex/panel-layout-v018-checkpoint

## Что исправлено

1. Добавлена отдельная зона вставки непосредственно под строкой вкладок документов; размещение над ней сохраняется. Строка использует прежний renderer и защищённый узел в единственном shared Workspace. Проверены повторная вставка, выбор/перетаскивание документов, крупные вкладки, close/reopen и сохранение/восстановление workspace.
2. В нижних углах составного плавающего блока сохраняется вертикальная составляющая resize, когда горизонтальную обрабатывают независимые части. Нижний край и оба угла проверены до любого изменения ширины, включая короткий сохранённый rect. Ширины соседей не меняются.
3. Раскрытие компактной группы восстанавливает нормальные размеры редакторов и split ratios. `stacked_sizes` хранит только размеры видимых частей группы, а `floating_sizes` — размеры самостоятельного редактора. Старые проверки отрыва и flyout сохраняют 320×400 и 320×450 соответственно. Проверены три цикла collapse/expand после resize при 100/125/150/200%, вертикальное/горизонтальное объединение, повреждённые входные размеры и обратная совместимость настроек.

До исправлений воспроизведены три регрессии: отсутствующая вставка под документными вкладками, короткие раскрытые редакторы и неработающий нижний угол. Логи `before-*.log` относятся к этим промежуточным проверкам. `full-ui-before-harness-fix.log` содержит отдельный уже исправленный дефект тестовой обвязки освобождения текстур; это не итоговая приёмка.

## Подтверждённые проверки

| Проверка | Результат |
|---|---|
| panel_docking | 164 passed, 2 явных benchmark ignored |
| shared docking | 346 passed |
| workspace integration | 9 passed |
| engine panic_hunt | 1 passed; повторно запущен сохранённый v0.18.0 test binary, engine в этом ремонте не менялся |
| desktop `cargo check --locked -p photocraft --all-targets` | passed |
| fmt | passed |
| layers | 31 crates, passed |
| wasm | 24 crates + codecs/heif, passed |
| полный UI library suite | 4494 passed, 95 failed, 23 ignored |

Все 95 имён сбоев полного UI-набора точно совпали с проверкой v0.18.0 до этого ремонта (`../v0.18-2026-10-31/full-ui-classification.json`). Новых имён нет. Это сравнение с нашим предыдущим snapshot, не заявление о зелёном полном suite или новом независимом baseline main. Полный UI-набор остаётся незелёным.

Строгий Clippy остаётся незелёным: зависимость `text/src/psd_path.rs:157`; UI `--no-deps` — прежние `canvas/strokes.rs:495,500`, `dialogs/vp_ui.rs:989`, `widgets/text_field.rs:29`, `dialogs/color_picker_ui/tests.rs:130`. Никаких suppressions или посторонних исправлений не добавлено. Команды и exit codes находятся в `verification-results.json`, полные выводы — в `.log`.

## Визуальные материалы и измерение

Свежие 444 PNG: 120 сценариев текущих трёх дефектов, 72 прежней desktop-матрицы, 120 швов и 132 финальных переходов. Все четыре capture-прогона прошли. Матрицы охватывают три Pro-темы и 100/125/150/200%. Пиксельные проверки разделителей прошли; выбранные PNG и контактные листы просмотрены. Дополнительно созданы 9 GIF последовательностей состояний и 3 контактных листа. SHA-256 находятся в `visual-sha256.json`.

CPU-замер kittest, 600 измерений на фазу, миллисекунды:

| Фаза | p50 | p95 |
|---|---:|---:|
{bench_rows}

Это стоимость тестового UI-кадра; она не измеряет native FPS, GPU-задержку или физический ввод. Общий `perf --quick` в этом этапе не запускался; прежний прерванный запуск не считается успешным измерением.

## Что остаётся проверить пользователю

Основной продуктовый EXE здесь не собирался и не запускался. Требуется пересборка и живая проверка сохранённой пользовательской компоновки: вставка под строкой документов, нижний край/оба угла до изменения ширины, высота после раскрытия и повторного сворачивания. Native focus/IME, реальные мониторы, mixed-DPI и GPU-задержки остаются неподтверждёнными.

Удалённая ветка PR `codex/panel-layout-upstream` осталась на `1c53e40a853acdde3b367162f24c00cd8e650441`; PR #10322 не редактировался, второй PR не создавался, merge не выполнялся. Более поздний main после release v0.18.0 не включался. План PR отложен до пользовательской проверки.

```powershell
Set-Location F:\\photocraft
& "$env:USERPROFILE\\.cargo\\bin\\cargo.exe" build --release --locked -p photocraft -j 2
```

EXE: `F:\\photocraft\\target\\release\\photocraft.exe`.
'''
(root/'RESULTS_RU.md').write_text(text,encoding='utf-8')
print('Final report generated; 444 PNG, known UI failures unchanged.')
