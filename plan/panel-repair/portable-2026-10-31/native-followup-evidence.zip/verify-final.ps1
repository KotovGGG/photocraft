$ErrorActionPreference='Continue'
Set-Location F:/photocraft
$env:PATH="$env:USERPROFILE/.cargo/bin;$env:PATH"
$env:CARGO_BUILD_JOBS='2'
$reviewRoot='F:/photocraft/plan/panel-repair/native-followup-2026-10-31'
function Invoke-ReviewCargo([string]$label, [string[]]$arguments) {
    & cargo @arguments *> "$reviewRoot/$label.log"
    Set-Content "$reviewRoot/$label.exit" $LASTEXITCODE
    Get-Content "$reviewRoot/$label.log" -Tail 3
}
Invoke-ReviewCargo 'full-ui' @('test','--locked','-p','photocraft-ui-egui','--lib','--','--test-threads=2')
Invoke-ReviewCargo 'workspace-integration' @('test','--locked','-p','photocraft-ui-egui','--test','it','workspace','--','--test-threads=2')
$testBinary='F:/photocraft/target/debug/deps/photocraft_ui_egui-7396fec2a7cf95cc.exe'
function Invoke-ReviewBinary([string]$label, [string[]]$arguments) {
    & $testBinary @arguments *> "$reviewRoot/$label.log"
    Set-Content "$reviewRoot/$label.exit" $LASTEXITCODE
    Get-Content "$reviewRoot/$label.log" -Tail 3
}
Invoke-ReviewBinary 'all-panels' @('panel_docking','--test-threads=2')
$env:PHOTOCRAFT_DESKTOP_REVIEW_CAPTURES="$reviewRoot/previous-matrix"
Invoke-ReviewBinary 'desktop-matrix' @('capture_desktop_review_matrix','--test-threads=1')
Remove-Item Env:PHOTOCRAFT_DESKTOP_REVIEW_CAPTURES
$env:PHOTOCRAFT_FOURTH_REVIEW_CAPTURES="$reviewRoot/previous-matrix"
Invoke-ReviewBinary 'seam-matrix' @('capture_fourth_review_seams','--test-threads=1')
Remove-Item Env:PHOTOCRAFT_FOURTH_REVIEW_CAPTURES
$env:PHOTOCRAFT_FINAL_REVIEW_CAPTURES="$reviewRoot/previous-matrix"
Invoke-ReviewBinary 'final-transitions' @('capture_final_review_transitions','--test-threads=1')
Remove-Item Env:PHOTOCRAFT_FINAL_REVIEW_CAPTURES
Invoke-ReviewBinary 'active-panel-benchmark' @('benchmark_panel_hover_and_drag_frames','--ignored','--nocapture','--test-threads=1')
Invoke-ReviewCargo 'fmt' @('fmt','--all','--','--check')
