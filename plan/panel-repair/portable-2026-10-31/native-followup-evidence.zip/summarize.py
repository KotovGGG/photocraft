from pathlib import Path
import json, re, hashlib, subprocess
root=Path('F:/photocraft/plan/panel-repair/native-followup-2026-10-31')
base=json.loads(Path('F:/photocraft/plan/panel-repair/v0.18-2026-10-31/full-ui-classification.json').read_text(encoding='utf-8'))['failed']
log=(root/'full-ui.log').read_text(encoding='utf-8',errors='replace')
failed=sorted(set(re.findall(r'^test (.+?) \.\.\. FAILED\s*$',log,re.M)))
summary=re.findall(r'test result: .*',log)
classification={'result':summary,'failed':failed,'new_failures':sorted(set(failed)-set(base)),'removed_failures':sorted(set(base)-set(failed)),'baseline':'v0.18-2026-10-31/full-ui-classification.json'}
(root/'full-ui-classification.json').write_text(json.dumps(classification,indent=2)+'\n',encoding='utf-8')
checks={}
for p in root.glob('*.exit'):
    label=p.stem; item={'exit':int(p.read_text(encoding='utf-8-sig').strip())}; logpath=p.with_suffix('.log')
    if logpath.exists():
        data=logpath.read_text(encoding='utf-8',errors='replace')
        item['results']=re.findall(r'test result: .*',data)
    checks[label]=item
(root/'verification-results.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',head],text=True).splitlines()
source={'commit':head,'base':'621d9238b7f8ccc31def22a2572615cb40143056','author':subprocess.check_output(['git','show','-s','--format=%an <%ae>'],text=True).strip(),'files':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},'backup_branch':'codex/panel-layout-v018-checkpoint','pr_remote_branch_unchanged':'1c53e40a853acdde3b367162f24c00cd8e650441'}
(root/'source.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
visuals=list((root/'matrix').glob('*.png'))+list((root/'previous-matrix').glob('*.png'))+list(root.glob('*.gif'))+list(root.glob('contact-*.png'))
(root/'visual-sha256.json').write_text(json.dumps({str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in visuals},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'full_ui':classification,'checks':checks,'visual_count':len(visuals)},indent=2))
