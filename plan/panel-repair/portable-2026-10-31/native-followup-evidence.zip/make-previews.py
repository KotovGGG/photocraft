from pathlib import Path
from PIL import Image, ImageDraw
import hashlib,json
root=Path('F:/photocraft/plan/panel-repair/native-followup-2026-10-31')
scenes=['under-documents-docked','vertical-expanded','vertical-restored','horizontal-expanded','bottom-corner-preview','bottom-corner-resized']
for theme in ['pro','proMedium','proLight']:
    sheet=Image.new('RGB',(1280,1272),(35,35,35));draw=ImageDraw.Draw(sheet)
    for i,name in enumerate(scenes):
        im=Image.open(root/'matrix'/f'{theme}-1-{name}.png').convert('RGB').resize((640,400),Image.Resampling.LANCZOS)
        x=i%2*640;y=i//2*424
        draw.text((x+8,y+4),name,fill='white');sheet.paste(im,(x,y+24))
    sheet.save(root/f'contact-{theme}.png')
    for name,frames in [('stack-height',['vertical-compact','vertical-expanded','vertical-collapsed-again','vertical-restored']),('bottom-corner',['horizontal-expanded','bottom-corner-preview','bottom-corner-resized']),('below-documents',['under-documents-preview','under-documents-docked','under-documents-collapsed'])]:
        images=[Image.open(root/'matrix'/f'{theme}-1.25-{scene}.png').convert('RGB').resize((1280,800),Image.Resampling.LANCZOS) for scene in frames]
        images[0].save(root/f'{theme}-{name}.gif',save_all=True,append_images=images[1:],duration=1500,loop=0)
files=list((root/'matrix').glob('*.png'))+list(root.glob('*.gif'))+list(root.glob('contact-*.png'))
(root/'visual-sha256.json').write_text(json.dumps({str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n',encoding='utf-8')
print(f'{len(list((root/"matrix").glob("*.png")))} PNG, {len(list(root.glob("*.gif")))} GIF, {len(list(root.glob("contact-*.png")))} contacts')
