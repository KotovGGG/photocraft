# PhotoCraft 0.19 integration, 2026-11-02

Shared API accepted: craft-libs#470 merge ea1fbeb05b94bb692b27b687adb2ac1e5abc640f.
PhotoCraft main: 289dd0a87. Backup: codex/panel-before-v019-2026-11-02 at a175b27c1.
Full reference branch merges current main; five conflicts reconciled by preserving source icon helper and upstream footer constants, both attribution fixture categories, both documentation histories; scorecard regenerated (10/183).
Local vendor and its snapshot-only build contract removed. Ignored local vendor fixtures moved intact into plan/panel-repair/retired-vendor-test-inputs-2026-11-02.
First consumer PR is deliberately just immutable dependency adoption (Cargo.toml/Cargo.lock) on a fresh-main worktree F:/photocraft-panel-integration, branch codex/panel-shared-ui-upstream. Only craft-ui and its same-repo transitive i18n/fonts-build lock sources move. Persistence, compact/resize, and Tools remain subsequent review units.

Root desktop check passed. Native-height/document-header capture test passed, 120 PNGs in v019-captures; pro-1-bottom-corner-resized.png inspected. Further focused tests/gates pending at time of this note.
Broad name filter panel selected 851 tests, encountered Color Wheel/Curves failures and was stopped; no full result/baseline conclusion. Use v019-docking.log for focused adapter results.
EXE not built or launched. Historical GIFs and earlier tests are not latest-main acceptance.
